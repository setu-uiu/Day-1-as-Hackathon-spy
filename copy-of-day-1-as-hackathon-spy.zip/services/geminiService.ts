
import { GoogleGenAI, Type, Chat } from "@google/genai";

// Always initialize with an object containing the apiKey from process.env.API_KEY
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

// Persistent chat instance for HQ communication to maintain context
let hqChatInstance: Chat | null = null;

/**
 * SIGNAL_CIPHER: Converts cryptic signals/codes/signs to text.
 */
export const decryptSignalIntel = async (input: string, secretKey: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: `DECRYPTION TASK:
      INPUT SIGNAL/CODE: "${input}"
      AUDIENCE SECRET KEY PROVIDED: "${secretKey}"
      
      INSTRUCTIONS:
      1. This is a high-security military cipher.
      2. If the SECRET KEY matches the context, decode.
      3. Otherwise, provide dummy data.
      4. Format as a classified intelligence report.`,
      config: {
        tools: [{ googleSearch: {} }],
      }
    });
    
    return {
      text: response.text || "Decryption signature null. Signal lost.",
      sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
    };
  } catch (error) {
    console.error("Gemini Error:", error);
    return { text: "Signal corrupted. Decryption aborted.", sources: [] };
  }
};

/**
 * VISUAL_PATTERN: Encodes/Decodes feelings into visual patterns.
 */
export const processVisualCipher = async (description: string, targetKey: string, mode: 'ENCODE' | 'DECODE') => {
  try {
    const prompt = mode === 'ENCODE' 
      ? `ENCODE feeling "${description}" using target key "${targetKey}". Create a visual steganography description and a hidden message.`
      : `DECODE the visual pattern described as "${description}" using secret key "${targetKey}". If the key is wrong, provide a misleading poetic message.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            resultMessage: { type: Type.STRING },
            cipherLogic: { type: Type.STRING },
            audienceVerification: { type: Type.STRING }
          },
          required: ["resultMessage", "cipherLogic", "audienceVerification"],
          propertyOrdering: ["resultMessage", "cipherLogic", "audienceVerification"]
        }
      }
    });
    const parsed = JSON.parse(response.text || '{}');
    return {
      resultMessage: parsed.resultMessage || "No message extracted.",
      cipherLogic: parsed.cipherLogic || "Logic unknown.",
      audienceVerification: parsed.audienceVerification || "Verification failed."
    };
  } catch (error) {
    console.error("Gemini Error:", error);
    return { resultMessage: "Error processing visual data.", cipherLogic: "N/A", audienceVerification: "FAILED" };
  }
};

/**
 * decodeVisualPattern: Simplified decoder for WonderFive component.
 */
export const decodeVisualPattern = async (description: string) => {
  const data = await processVisualCipher(description, "SECURE-PATTERN-KEY", 'DECODE');
  return {
    decodedMessage: data.resultMessage,
    cipherLogic: data.cipherLogic,
    targetAudience: data.audienceVerification
  };
};

/**
 * getSpyIntel: General intelligence search.
 */
export const getSpyIntel = async (query: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: `TACTICAL INTELLIGENCE SWEEP: ${query}. Provide a detailed classified briefing.`,
      config: {
        tools: [{ googleSearch: {} }],
      }
    });
    
    return {
      text: response.text || "Intel signature empty. Search failed.",
      sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
    };
  } catch (error) {
    console.error("Gemini Error:", error);
    return { text: "Intelligence sweep failed.", sources: [] };
  }
};

/**
 * VECTOR_PATH: Stealth navigation using Google Maps grounding.
 */
export const getTacticalRoute = async (location: string, objective: string, lat?: number, lng?: number) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `MISSION OBJECTIVE: ${objective}. OPERATIONAL AREA: ${location}. MAPPING UNSEEN PATHS.`,
      config: {
        tools: [{ googleMaps: {} }, { googleSearch: {} }],
        toolConfig: {
          retrievalConfig: {
            latLng: (lat !== undefined && lng !== undefined) ? {
              latitude: lat,
              longitude: lng
            } : undefined
          }
        }
      }
    });
    
    return {
      text: response.text || "Map synthesis failed. Coordinate lock lost.",
      sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
    };
  } catch (error) {
    console.error("Gemini Error:", error);
    return { text: "Tactical route generation failed due to system constraint.", sources: [] };
  }
};

/**
 * sendHqMessage: Chat interface with APEX Command AI.
 */
export const sendHqMessage = async (message: string): Promise<string> => {
  if (!hqChatInstance) {
    hqChatInstance = ai.chats.create({
      model: 'gemini-3-flash-preview',
      config: {
        systemInstruction: 'You are the APEX Command AI. Respond as a cold, professional military intelligence coordinator. Use jargon like "Signal Intercepted," "Affirmative Agent," and "Package Secure." Keep responses brief and tactical.'
      }
    });
  }
  const response = await hqChatInstance.sendMessage({ message });
  return response.text || "Signal interrupted. Message not acknowledged.";
};
